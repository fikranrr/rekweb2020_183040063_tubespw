<?php

function koneksi (){
    $conn = mysqli_connect("localhost", "root", "") or die ("Koneksi ke DB gagal");
    mysqli_select_db($conn, "tubes_pw_183040063") or die ("Database salah!");

    return $conn;
}


function tambah($data) {
    global $conn;
    
    $mdl = htmlspecialchars($data["Model"]);
    $brd = htmlspecialchars($data["Brand"]);
    $tipe = htmlspecialchars($data["Tipe"]);
    $wrna = htmlspecialchars($data["Warna"]);
    $photo = htmlspecialchars($data["Foto"]);
    
    // Query insert data 
    $query = "INSERT INTO mobil VALUES 
                ('', '$mdl', '$brd', '$tipe', '$wrna', '$photo')
             ";
    mysqli_query($conn, $query);
    
    return mysqli_affected_rows($conn);
}

function hapus($id) {
    global $conn;
    mysqli_query($conn, "DELETE FROM mobil WHERE id = $id");
    
    return mysqli_affected_rows($conn);
}


function ubah($data) {
    global $conn;
    
    $id = $data["id"];
    $mdl = htmlspecialchars($data["Model"]);
    $brd = htmlspecialchars($data["Brand"]);
    $tipe = htmlspecialchars($data["Tipe"]);
    $wrna = htmlspecialchars($data["Warna"]);
    $photo = htmlspecialchars($data["Foto"]);
    
    // Query insert data 
    $query = "UPDATE mobil SET 
                Model = '$mdl',
                Brand = '$brd',
                Tipe = '$tipe',
                Warna = '$wrna',
                Foto = '$photo'
             WHERE id = $id
             ";
    mysqli_query($conn, $query);
    
    return mysqli_affected_rows($conn);
}

function cari($keyword) {
    $query = "SELECT * FROM mobil WHERE
                Model LIKE '%$keyword%' OR
                Brand LIKE '%$keyword%' OR
                Tipe LIKE '%$keyword%' OR
                Warna LIKE '%$keyword%'
            ";
    return query($query);
}

function query($sql) {
    $conn = koneksi();
    $results = mysqli_query($conn, "$sql");

    $rows = [];
    while ($row = mysqli_fetch_assoc($results)){
        $rows[]= $row;
    };

    return $rows;
}






?>