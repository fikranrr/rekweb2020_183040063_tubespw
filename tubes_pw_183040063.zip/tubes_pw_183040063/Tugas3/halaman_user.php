  <?php
require 'function.php';
 $mobil = query("SELECT * FROM mobil");


if( isset($_POST["cari"]) ) {
	$mobil = cari($_POST["keyword"]);
}

if (isset($_POST['submit'])) {
	if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin') {
		header("location: index.php");
		exit;
	} else {
		$nValid = true;
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title></title>
</head>
	<style>
		.container {
			border: 1px solid black;
			text-align: center;
			font-size: 20px;
			background-color : white;
			margin-left: 365px;
            margin-right: 365px;
		}
		.content {
			
		}
		.gambar {
			
		}
		
		.login {
			width: 60px;
			height: 20px;
			background-color: salmon;
			border-radius: 20px;
			text-align: center;
			margin: auto;
		}
	</style>
<body bgcolor="grey">
	<center><h2>Daftar Mobil Terlaris</h2></center>
	<form action="" method="post">
		<div class="login">
		<center><a href="login_admin.php">Login</a></center>
		</div>
		<br><br>
		<center><input type="text" name="keyword" size="45" autofocus placeholder="Masukan keyword pencarian mobil..." autocomplete="off">
		<button type="submit" name="cari">Cari</button></center>
	</form>
	<br>
 <div class="container">
 			<?php foreach ($mobil as $m) : ?>
        <div class="content">
           <div class="gambar">
                   <p><img src="../Modul 7/asset/img/<?= $m['foto']; ?>">
           </div>
            <p class="nama">
				<a href="profile.php?id=<?= $m['id']; ?>"><?= $m['model']; ?></a>
			</p>
			<p><?= $m['warna']; ?></p>
			<?php endforeach; ?>
        </div>
 </div>
</body>
</html>