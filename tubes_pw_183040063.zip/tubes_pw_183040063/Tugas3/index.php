 <?php
 session_start();

//cek apakah user sudahh login
if (!isset($_SESSION['username_a'])) {
  header("location:user.php");

}
require 'function.php';

$mobil = query("SELECT * FROM mobil");
 
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Daftar Mobil</title>
</head>
<body> 
	<h2 align="center">Daftar Mobil Terlaris</h2>
	
	<center><button><a href="tambah.php">Tambahkan Data Mobil</a></button></center>
		<br><br>
	
	<form action="" method="post">
		<center><input type="text" name="keyword" size="45" autofocus placeholder="Masukan keyword pencarian..." autocomplete="off">
		<button type="submit" name="cari">Cari</button></center>
	</form>
	<br>
	<table align="center" border="1"  cellspacing="0" cellpadding="10">
			<tr>
				<th>#</th>
				<th>Opsi</th>
				<th>Foto</th>
				<th>Model</th>
				<th>Brand</th>
				<th>Tipe</th>
				<th>Warna</th>
			</tr>
			<?php $i = 1; ?>	
				<?php foreach($mobil as $m) : ?>
			<tr>
				<td><?= $i++ ?></td>
				<td><a href="ubah.php?id=<?= $m["id"]; ?> ">Ubah</a> | 
					<a href="hapus.php?id=<?= $m["id"]; ?>" onClick="return confirm('Yakin akan dihapus?')">Hapus</a>
				</td>
				<td><img src="../Modul 7/asset/img/<?= $m['foto']; ?>"></td>
				<td><?= $m['model']; ?></td>
				<td><?= $m['brand']; ?></td>
				<td><?= $m['tipe']; ?></td>
				<td><?= $m['warna']; ?></td>
			</tr>
				<?php endforeach; ?>
	</table>
	
	
</body>
</html> 