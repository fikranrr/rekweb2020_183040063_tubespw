<?php
if(!isset($_GET['id'])) {
	header("Location: index.php");
	exit;
}

require 'function.php';
$id = $_GET['id'];

$m = query("SELECT * FROM mobil WHERE id = $id")[0];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>183040063</title>
</head>

<style>
	.content {
		border: 1px solid black;
			text-align: center;
			font-size: 20px;
			background-color : aqua;
			margin-left: 365px;
            margin-right: 365px;
	} 

</style>
<body bgcolor="grey">
   <div class="content">
   		<h3>Data Mobil Terlaris</h3>
           <div class="gambar">
                   <p><img src="../Tugas3/asset/img/<?= $m['foto']; ?>">
           </div>
		<div class="desc">
            <p class="nama"><?= $m['model']; ?></p>
			<p><?= $m['brand']; ?></p>
			<p><?= $m['tipe']; ?>, <?= $m['warna']; ?></p>
			<p><a href="user.php">Kembali</a></p>
		</div>
   </div>
</body>
</html>