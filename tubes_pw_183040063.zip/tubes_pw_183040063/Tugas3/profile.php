<?php
if(!isset($_GET['id'])) {
	header("Location: index.php");
	exit;
}

require 'function.php';
$id = $_GET['id'];

$m = query("SELECT * FROM mobil WHERE id = $id")[0];
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>183040063</title>
</head>
<style> 

</style>
<body>
<h1>Detail Mobil</h1>
   <div class="content">
           <div class="gambar">
                   <p><img src="../Modul 7/asset/img/<?= $m['foto']; ?>">
           </div>
		<div class="desc">
            <p class="nama"><?= $m['model']; ?></p>
			<p><?= $m['brand']; ?></p>
			<p><?= $m['tipe']; ?>, <?= $m['warna']; ?></p>
			<p><a href="halaman_user.php">Kembali</a></p>
		</div>
   </div>
</body>
</html>