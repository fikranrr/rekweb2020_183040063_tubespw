<?php
//Connet To Databases
require 'function.php';
//Tombol Submit mengecek sudah di tekan atau belum
if( isset($_POST["submit"]) ) {
//Pengecekan Berhasil Apa gagal
	if( tambah($_POST) > 0 ) {
		print "
			<script>
				alert('Data Berhasil Ditambahkan!');
				document.location.href = 'index.php';
			</script>
		";
	} else {
		print "
			<script>
				alert('Data Gagal Ditambahkan!');
				document.location.href = 'index.php';
			</script>
		";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Daftar Mobil</title>
</head>
<body>
	<center><h2>Tambah Daftar Mobil</h2></center>
		<form method="post" action="">
			<ul align="center">
			
				<label for="Masukan model mobil">Masukan model mobil : </label> 
				<br>
				<input type="text" name="Mobil" required>
				
				
				<br><br>
				
		
				<label for="Masukan Brand">Masukan Brand Mobil :</label>
				<br>
				<input type="text" name="Brand" required>
				
				
				<br><br>
				
				
				<label for="Masukan Tipe">Masukan Tipe Mobil :</label>	 
				<br>
				<input type="text" name="Tipe" required>
				
				
				<br><br>
				
				
				<label for="Masukan Warna">Masukan Warna Mobil :</label>	 
				<br>	 
				<input type="text" name="Warna" required>
				
				
				<br><br>
				
				<label for="Masukan Foto">Masukan Foto :</label>		 
				<br>
				<input type="text" name="Foto" required>
				
				
				<br><br>
				
				<td>
					<button type="submit" name="submit">Tambah Data</button>
				</td>
			</ul>
		</form>
	
	
	
	
</body>
</html>