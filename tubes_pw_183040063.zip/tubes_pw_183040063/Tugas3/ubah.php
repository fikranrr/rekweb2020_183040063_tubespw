<?php
require 'function.php';

$id = $_GET["id"];
$B = query("SELECT * FROM mobil WHERE id = $id")[0];

if( isset($_POST['submit'])){
    if(tambah($_POST) > 0 ){
        print "<script>
            alert('data berhasil diubah');
            document.location.href = 'index.php';
            </script>";
    }else{
        print "<script>
            alert('data gagal diubah');
            document.location.href = 'index.php';
            </script>";
    }
}
?>

<html>
    <head>
        <title>Tambah Data Mobil</title>
    </head>
    <body>
        <h1>FORM ubah Data Mobil</h1>
        <form action="" method="post">
            <input type="hidden" name="id" value="<?=$m["id"];?>">

            <label for="Model"> Model : </label><br>
            <input type="text" name="Model" id="Model" value="<?=$m['model'];?>" required><br>

            <label for="Brand">Brand : </label><br>
            <input type="text" name="Brand" id="Brand" value="<?=$m['brand'];?>" required><br>

            <label for="Tipe">Tipe </label><br>
            <input type="textarea" name="Tipe" id="Tipe" value="<?=$m['tipe'];?>" required><br>

            <label for="Warna">Warna : </label><br>
            <input type="text" name="Warna" id="Warna" value="<?=$m['warna'];?>" required><br>

            <label for="Foto">Foto : </label><br>
            <input type="text" name="Foto" id="Foto" value="<?=$m['foto'];?>" required><br>
            <br>
            <button type="submit" name="submit">Ubah</button>
        </form>
    </body>
</html>