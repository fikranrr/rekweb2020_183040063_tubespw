  <?php
require 'function.php';
 $mobil = query("SELECT * FROM mobil");

 if( isset($_POST['cari'])) {
 	$mobil = cari($_POST['keyword']);
 }
 if(isset($_POST['submit'])) {
 	if ($_POST['username'] == 'admin' && $_POST['password'] == 'admin') {
 		header("location: index.php");
 		exit;
 	}else{
 		$nValid = true;
 	}
 }
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>183040063</title>
</head>
	<style>
		.container {
			text-align: center;
		}
		.content {
			
		}
		.gambar {
			
			
		}
		.login {
			width: 80px;
			height: 60px;
			background-color: salmon;
			border-radius: 20px;
			margin:auto;
		}
	</style>
<body bgcolor="grey">
	<center><h2>Daftar Mobil</h2></center>
	<form action="" method="post">
		<div class="login">
          <center><a href="login_admin.php">Login sebagai admin</a></center>
            </div>
            <br><br>
            <center><input type="text" name="keyword" size="45" autofocus placeholder="Masukan keyword pencarian Mobil" autocomplete="off">
            <button type="submit" name="cari">Cari</button></center>
	</form>
	<br>
 <div class="container">
 			<?php foreach ($mobil as $m) : ?>
        <div class="content">
           <div class="gambar">
                   <p><img src="../Modul 7/asset/img/<?= $m['foto']; ?>">
           </div>
            <p class="nama">
				<a href="profil.php?id=<?= $m['id']; ?>"><?= $m['model']; ?></a>
			</p>
			<p><?= $m['warna']; ?></p>
			<?php endforeach; ?>
        </div>
 </div>
</body>
<center><a href="../index.php">Back to Index</a></center>
</html>