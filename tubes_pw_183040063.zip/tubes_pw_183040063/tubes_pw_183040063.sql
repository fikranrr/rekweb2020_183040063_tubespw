-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2019 at 11:25 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tubes_pw_183040063`
--

-- --------------------------------------------------------

--
-- Table structure for table `mobil`
--

CREATE TABLE `mobil` (
  `id` int(11) NOT NULL,
  `brand` varchar(32) NOT NULL,
  `model` varchar(32) NOT NULL,
  `tipe` varchar(32) NOT NULL,
  `warna` varchar(32) NOT NULL,
  `foto` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobil`
--

INSERT INTO `mobil` (`id`, `brand`, `model`, `tipe`, `warna`, `foto`) VALUES
(1, 'Toyota', 'Avanza', 'Low MPV', 'Silver ', '1.JPG'),
(2, 'Honda', 'BR-V', 'Low SUV', 'Black', '2.JPG'),
(3, 'Toyota', 'Innova', 'MPV', 'Silver', '3.JPG'),
(4, 'Toyota', 'Agya', 'LCGC', 'Red', '4.PNG'),
(5, 'Honda', 'Mobilio', 'Low MPV', 'Silver', '5.JPG'),
(6, 'Daihatsu', 'Ayla', 'LCGC', 'Silver', '6.JPG'),
(7, 'Honda', 'HR-V', 'Low MPV', 'Silver', '7.JPG'),
(8, 'Suzuki', 'Ertiga', 'Low MPV', 'Black', '8.JPG'),
(9, 'Datsun', 'Go Series', 'LCGC', 'Silver', '9.JPG'),
(10, 'Daihatsu', 'Xenia', 'Low MPV', 'Silver', '10.JPG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mobil`
--
ALTER TABLE `mobil`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mobil`
--
ALTER TABLE `mobil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
